from sklearn.metrics import accuracy_score, recall_score, f1_score

def evaluate_model(y_test, y_pred):
    return {
        "accuracy": accuracy_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred)
    }