from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

def train_models(X_train, y_train):
    lr = LogisticRegression(max_iter=1000)
    rf = RandomForestClassifier(n_estimators=100)

    lr.fit(X_train, y_train)
    rf.fit(X_train, y_train)

    return lr, rf