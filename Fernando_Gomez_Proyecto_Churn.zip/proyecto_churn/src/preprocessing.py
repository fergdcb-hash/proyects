import pandas as pd

def load_data(path):
    df = pd.read_csv(path)

    # eliminar ID
    if "customerID" in df.columns:
        df = df.drop("customerID", axis=1)

    # convertir TotalCharges (sin borrar filas)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

    # limpiar churn SIN eliminar filas
    df["Churn"] = df["Churn"].astype(str).str.strip()

    # mapear
    df["Churn"] = df["Churn"].map({"Yes":1, "No":0})

    return df


def encode_data(df):
    return pd.get_dummies(df, drop_first=True)